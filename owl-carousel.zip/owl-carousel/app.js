//owl carousel start
$(".owl-carousel").owlCarousel({
    autoplay:true,
    loop:true,
    autoplayTimeout:1000,
    padding:10,
    margin:10,
    dots: true,
    stagePadding: -5,
    responsiveBaseElement: 'body',
    autoplayHoverPause: true,

    responsive:{
        1000:{
            items: 4
        },
        600:{
            items:3
        },
        0:{
            items:1
        }
    }
});
//owl carousel end