$(window).scroll(()=>{
    $(".navbar").toggleClass("nav-color",$(window).scrollTop()>100)
});

$("#btn").click(()=>{
    alert("hello");
})