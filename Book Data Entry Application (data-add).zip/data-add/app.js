var add_btn = document.getElementById("add_btn");
var b_id = document.getElementById("b_id");
var b_title = document.getElementById("b_title");
var b_sub_title = document.getElementById("b_sub_title");
var auth_id = document.getElementById("auth_id");
var b_category = document.getElementById("b_category");
var b_sub_category = document.getElementById("b_sub_category");
var b_subject = document.getElementById("b_subject");
var pub_id = document.getElementById("pub_id");
var ave_edi = document.getElementById("ave_edi");
var isbn_no = document.getElementById("isbn_no");
var copyright = document.getElementById("copyright");
var volume = document.getElementById("volume");
var b_location = document.getElementById("b_location");
var b_shelf = document.getElementById("b_shelf");

var book_add_msg = document.getElementById("book_add_msg");

var tbody = document.getElementById("tbody");

add_btn.addEventListener('click', function(block){
	block.preventDefault();
	
	if(b_id.value == "" || b_title.value == "" || b_location.value == "" || b_shelf.value == ""){
		alert("Book Id, Title, Location and Shelf Can not be empty !!!");
	}else if(b_id.value.length != 7){
		alert("Book Id Length Must be 7 Carecter !!!");
	}else{
		
		var tr = document.createElement("tr");
		
		var link = document.createElement("a");
		link.style.textDecoration = "none";
		link.style.backgroundColor = "blue";
		link.style.color = "white";
		link.style.padding = 5 + "px";
		link.style.textAlign = "center";
		var attr = link.setAttribute("href", "#");
		link.innerHTML = "Select";
		console.log(link);
		
		var td_link = document.createElement("td");
		td_link.appendChild = link;
		tr.appendChild(link);
		console.log(tr);
		
		var td = document.createElement("td");
		td.innerHTML = b_id.value;
		tr.appendChild(td);
		
		var td1 = document.createElement("td");
		td1.innerHTML = b_title.value;
		tr.appendChild(td1);
		
		var td2 = document.createElement("td");
		td2.innerHTML = b_sub_title.value;
		tr.appendChild(td2);
		
		var td3 = document.createElement("td");
		td3.innerHTML = auth_id.value;
		tr.appendChild(td3);
		
		var td4 = document.createElement("td");
		td4.innerHTML = b_category.value;
		tr.appendChild(td4);
		
		var td5 = document.createElement("td");
		td5.innerHTML = b_sub_category.value;
		tr.appendChild(td5);
		
		var td6 = document.createElement("td");
		td6.innerHTML = b_subject.value;
		tr.appendChild(td6);
		
		var td7 = document.createElement("td");
		td7.innerHTML = pub_id.value;
		tr.appendChild(td7);
		
		var td8 = document.createElement("td");
		td8.innerHTML = ave_edi.value;
		tr.appendChild(td8);
		
		var td9 = document.createElement("td");
		td9.innerHTML = isbn_no.value;
		tr.appendChild(td9);
		
		var td10 = document.createElement("td");
		td10.innerHTML = copyright.value;
		tr.appendChild(td10);
		
		var td11 = document.createElement("td");
		td11.innerHTML = volume.value;
		tr.appendChild(td11);
		
		var td12 = document.createElement("td");
		td12.innerHTML = b_location.value;
		tr.appendChild(td12);
		
		var td13 = document.createElement("td");
		td13.innerHTML = b_shelf.value;
		tr.appendChild(td13);
		
		tbody.appendChild(tr);
		
		//book_add_msg.innerHTML = "Data Add Successful";
		alert("Data Add Successful");
	}
		
})