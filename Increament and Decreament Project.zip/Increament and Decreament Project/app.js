// Increament code start
function increm(){
    var input_num = document.getElementById("input_num");

    if(input_num.value >= 5){
        input_num.value = 5;
        alert("Maximum 5 Number Allow");
    }else{
        input_num.value++;
    }
}
// Increament code end
// Decreament code start
function decrem(){
    var input_num = document.getElementById("input_num");

    if(input_num.value <= 0){
        input_num.value = 0;
        alert("Minimum 1 Number Allow");
    }else{
        input_num.value--;
    }
}
// Decreament code end