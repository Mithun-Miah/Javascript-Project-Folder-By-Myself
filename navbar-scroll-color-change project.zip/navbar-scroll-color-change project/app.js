var navbar = document.getElementById("navbar");

window.onscroll = function(){
    var up_down_scroll = window.scrollY;

    if(up_down_scroll >= 150){
        navbar.classList.add("change-color");
    }else{
        navbar.classList.remove("change-color");
    }
}