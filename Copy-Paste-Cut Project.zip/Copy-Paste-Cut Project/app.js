// Copy Code Start
var copy_btn = document.getElementById("copy_btn");
var copy_input = document.getElementById("copy_input");

copy_btn.addEventListener('click', function(){
    navigator.clipboard.writeText(copy_input.value);
    alert("Copy Text");
})
// Copy Code End

// Paste Code Start
var paste_btn = document.getElementById("paste_btn");
var paste_input = document.getElementById("paste_input");

paste_btn.addEventListener('click', function(){
    paste_input.value == "";
    navigator.clipboard.readText().then(function(text){
        paste_input.value = text;
        alert("Text Paste Success");
    })

})
// Paste Code End

// Cut Code Start
var cut_input = document.getElementById("cut_input");
var cut_btn = document.getElementById("cut_btn");

cut_btn.addEventListener('click', function(){

    navigator.clipboard.writeText(cut_input.value);

    cut_input.value = "";
    alert("Text Cut Success");
})
// Cut Code End