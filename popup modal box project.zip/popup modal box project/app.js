// popup modal code start
var popup_btn = document.getElementById("popup_btn");
var popup_box = document.getElementById("popup_box");

popup_box.style.display = "none";

popup_btn.addEventListener('click', function(){
    if(popup_box.style.display == "none"){
        popup_box.style.display = "block";
    }else{
        popup_box.style.display = "none";
    }
})
// popup modal code end
