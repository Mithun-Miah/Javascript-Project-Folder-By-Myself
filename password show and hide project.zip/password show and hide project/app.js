// Password Hide & Show Code Start
var eye_btn = document.getElementById("eye_btn");
var pass_input = document.getElementById("pass_input");

eye_btn.addEventListener('click', function(){

    if(pass_input.type == "password"){
        pass_input.type = "text";
    }else{
        pass_input.type = "password";
    }
})
// Password Hide & Show Code End

