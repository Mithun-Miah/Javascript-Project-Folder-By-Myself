//count effect start

$(".count").counterUp({
    time:2000,
    delay:10
});

//count effect end