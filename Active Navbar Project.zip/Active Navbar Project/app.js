var navbarMenu = document.querySelectorAll("a");

var current_location = location.href;

for(var i = 0; i<=navbarMenu.length; i++){
    if(navbarMenu[i].href === current_location){
        navbarMenu[i].className = "active-nav-menu";
    }
}