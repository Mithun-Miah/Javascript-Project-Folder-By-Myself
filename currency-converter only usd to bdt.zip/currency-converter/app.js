// Convert Code Start
var convert_btn = document.getElementById("convert_btn");
var input1 = document.getElementById("num1");
var input2 = document.getElementById("num2");

convert_btn.addEventListener('click', function(event){
	//event.preventDefault();
	
	var conv1 = parseFloat(input1.value);
	var conv2 = parseFloat(input2.value);
	
	var usd_rate = 95.16;
	
	if(conv1 > 0){
		var multi = conv1 * usd_rate;
		document.getElementById("num2").value = multi.toFixed(2);		
	}
	
});
// Convert Code End

// Clear Input Field value Start
var clear_btn = document.getElementById("clear_btn");

clear_btn.addEventListener('click', ()=>{
	input1.value = "";
	input2.value = "";
})
// Clear Input Field value End