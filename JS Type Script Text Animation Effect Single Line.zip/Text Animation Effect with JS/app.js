let title = document.querySelector("h1");
let text = "Hello! My Name Mithun";
// console.log(text);
let index = 0;
setInterval(fun,100);
function fun(){
    title.innerHTML = text.slice(0, index++);
    //console.log(index);
    if(index>text.length){
        index = 0;
    }
}