var start_car = document.getElementById("start_car");
var stop_car = document.getElementById("stop_car");
var car_image = document.getElementById("car_image");

var interval;
var ml = 0;
// car start code start
start_car.addEventListener('click', function(){
    interval = setInterval(run, 100);

    function run(){
        if(ml == 800){
            ml = 0;
        }else{
            ml+=10;
            car_image.style.marginLeft = ml + 'px';
        }
    }
})
// car start code end

// car stop code start
stop_car.addEventListener('click', function(){
    clearInterval(interval);
})
// car stop code end