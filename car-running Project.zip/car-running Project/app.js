// car running code start
var car_image = document.getElementById("car_image");
var start_car = document.getElementById("start_car");
var stop_car = document.getElementById("stop_car");

var interval;
var marg = 0;

start_car.addEventListener('click', function(){
    interval = setInterval(run, 100);

    function run(){
        if(marg == 800){
            clearInterval(interval);
            marg = 0;
        }else{
            marg+=10;
            car_image.style.marginLeft = marg + 'px';
            //console.log(marg);
        }
    }
})

stop_car.addEventListener('click', function(){
    clearInterval(interval);
})
// car running code end

// text running code start
var start_txt = document.getElementById("start_txt");
var stop_txt = document.getElementById("stop_txt");
var text_anim = document.getElementById("text_anim");

var time;
var marg_l = 0;

start_txt.addEventListener('click', function(){
    time = setInterval(text_run, 100);

    function text_run(){
        if(marg_l == 680){
            //clearInterval(time);
            marg_l = 0;
        }else{
            marg_l+=10;
            text_anim.style.marginLeft = marg_l + 'px';
            //console.log(marg_l);
        }
    }
})
// text running code end
// text stop code start
stop_txt.addEventListener('click', function(){
    clearInterval(time);
})
// text stop code end