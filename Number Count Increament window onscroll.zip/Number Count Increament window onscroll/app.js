// For Number Counters Start

window.onscroll = function(e){
    // for project
    var count = 0;
    var project = setInterval(project, 20);

    function project(){
        count++;
        var num1 = document.getElementById("num1").innerHTML = count;
        if(count == 200){
            clearInterval(project);
        }
    }

    // for client
    var count2 = 0;
    var client = setInterval(client, 30);

    function client(){
        count2++;
        var num2 = document.getElementById("num2").innerHTML = count2;
        if(count2 == 150){
            clearInterval(client);
        }
    }
    // for archive
    var count3 = 0;
    var archive = setInterval(archive, 100);

    function archive(){
        count3++;
        var num3 = document.getElementById("num3").innerHTML = count3;
        if(count3 == 25){
            clearInterval(archive);
        }
    }

}

// For Number Counters Finish