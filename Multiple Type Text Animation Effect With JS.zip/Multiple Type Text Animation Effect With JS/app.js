var textArray = ["Digital Experience","with Orbitor"];

var count = 0;
var index = 0;
var currentText = 0;
var letter = 0;

setInterval(textFun,100);

function textFun(){
	currentText = textArray[count];
	letter = currentText.slice(0, index++);
	//console.log(index);
	var placeText = document.querySelector("h1").innerHTML = letter;
	
    if(letter.length == currentText.length){
		count++;
		//console.log(count);
        index = 0;
    }
	if(count == textArray.length){
		count = 0;
	}
}