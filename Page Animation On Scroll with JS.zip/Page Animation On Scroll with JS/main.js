window.addEventListener('scroll', function(){
    let main1 = document.getElementById("main1");
    let contentPosition = main1.getBoundingClientRect().top;
    let scrollY = window.scrollY;

    if(contentPosition < scrollY){
        main1.classList.add("active");
    }else{
        main1.classList.remove("active");
    }
})

window.addEventListener('scroll', function(){
    let main2 = document.getElementById("main2");
    let contentPosition2 = main2.getBoundingClientRect().top;
    let scrollY2 = window.scrollY;

    if(contentPosition2 < scrollY2){
        main2.classList.add("active2");
    }else{
        main2.classList.remove("active2");
    }
})