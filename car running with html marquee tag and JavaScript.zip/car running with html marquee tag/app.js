var start_btn = document.getElementById("start");
var stop_btn = document.getElementById("stop");
var car_img = document.getElementById("car_img");

// Car Stop by Default Code
car_img.stop();
/*
=============================================
*/
// Car Start Code Start
start_btn.addEventListener('click', ()=>{
	
	car_img.start();
});
// Car Start Code End =================

// Car Stop Code Start
stop_btn.addEventListener('click', ()=>{
	
	car_img.stop();
});
// Car Stop Code End ===================


