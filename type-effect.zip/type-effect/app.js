//types effect start

var type = new Typed(".title",{
    strings:["Web Designer","Front-End Web Developer","Back-End Web Developer","Full-Stack Web Developer","PHP Developer"],
    loop:true,
    typeSpeed:100
});
console.log(type);

//types effect end